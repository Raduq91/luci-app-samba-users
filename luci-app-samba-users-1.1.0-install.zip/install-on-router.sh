#!/bin/sh
# Run this ON the OpenWrt router (as root), with the tarball in the same directory
# or pass path: ./install-on-router.sh /tmp/luci-app-samba-users-files.tar.gz

set -e
TAR="${1:-./luci-app-samba-users-files.tar.gz}"

if [ ! -f "$TAR" ]; then
	echo "Usage: $0 [path-to-luci-app-samba-users-files.tar.gz]"
	exit 1
fi

echo "Extracting files to / ..."
tar -C / -xzf "$TAR"

echo "Restarting rpcd ..."
/etc/init.d/rpcd restart

echo "Done."
echo "Log out of LuCI and log back in."
echo "Page: Services → Samba Users"
echo ""
echo "Optional (only what you use):"
echo "  apk add ksmbd-utils     # for ksmbd"
echo "  apk add samba4-utils    # for Samba4"
